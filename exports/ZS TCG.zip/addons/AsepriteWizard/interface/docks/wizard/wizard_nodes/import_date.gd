@tool
extends Label


func set_date(timestamp: String):
	self.text = timestamp
#	self.text = _format_date(timestamp)


#func _format_date(timestamp: int) -> String:
#	var dt = Time.get_datetime_dict_from_system_from_unix_time(timestamp)
#	return "%04d-%02d-%02d %02d:%02d:%02d" % [dt.year, dt.month, dt.day, dt.hour, dt.minute, dt.second]
